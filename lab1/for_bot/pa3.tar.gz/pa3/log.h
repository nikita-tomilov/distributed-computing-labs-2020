#pragma once

void fail_gracefully(char* fail_string);
void fail_custom(char* fail_string);
void llog(FILE* file, const char* fmt, ...);
