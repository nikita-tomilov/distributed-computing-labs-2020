#include "banking.h"
#include "ipc.h"
#include "main.h"
#include "message.h"

#include <unistd.h>

void transfer(void * parent_data, local_id src, local_id dst, balance_t amount) {

}
